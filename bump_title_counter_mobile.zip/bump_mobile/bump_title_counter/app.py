import io
import re
from pathlib import Path
from typing import Iterable

import pandas as pd
import streamlit as st
from PIL import Image

st.set_page_config(page_title="BUMP 配信作品カウンター", page_icon="🎬", layout="wide")

APP_TITLE = "BUMP 配信作品カウンター"

# UI上で作品名として扱わない可能性が高い短い語・メニュー語
DEFAULT_EXCLUDES = {
    "bump", "ホーム", "ランキング", "検索", "マイページ", "作品", "新着", "おすすめ",
    "視聴中", "無料", "話", "全話", "もっと見る", "続きを見る", "カテゴリ", "ジャンル",
    "フォロー", "シェア", "再生", "予告", "字幕", "吹替", "ログイン", "登録",
}


def normalize_text(text: str) -> str:
    """OCRテキストを比較・重複除去しやすい形に整える。"""
    text = text.replace("\u3000", " ").strip()
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"^[・･●○▶▷►\-–—|｜]+", "", text).strip()
    text = re.sub(r"[|｜]+$", "", text).strip()
    return text


def title_key(text: str) -> str:
    """表記ゆれを吸収するための比較キー。"""
    text = normalize_text(text).lower()
    text = re.sub(r"[\s\-‐‑‒–—―・･!！?？:：,，.。'’\"“”\(\)（）\[\]【】]+", "", text)
    return text


def is_probable_title(text: str, excludes: set[str], min_chars: int, max_chars: int) -> bool:
    t = normalize_text(text)
    if not t:
        return False
    if t.lower() in excludes or t in excludes:
        return False
    if len(t) < min_chars or len(t) > max_chars:
        return False
    if re.fullmatch(r"[\d\s.,:/\-]+", t):
        return False
    if re.fullmatch(r"第?\d+話", t):
        return False
    if re.fullmatch(r"\d+[万千]?回?", t):
        return False
    if re.search(r"(再生|視聴|無料|ランキング|フォロー|シェア)$", t):
        return False
    # 日本語・英字・数字のいずれかがあること
    if not re.search(r"[ぁ-んァ-ヶ一-龠A-Za-z0-9]", t):
        return False
    return True


@st.cache_resource(show_spinner="OCRエンジンを準備しています…")
def load_reader():
    try:
        import easyocr
    except ImportError as exc:
        raise RuntimeError("EasyOCRがインストールされていません。requirements.txt を使ってインストールしてください。") from exc
    # 初回のみ日本語・英語モデルを取得
    return easyocr.Reader(["ja", "en"], gpu=False, verbose=False)


def run_ocr(image: Image.Image) -> list[tuple[str, float]]:
    reader = load_reader()
    import numpy as np

    arr = np.array(image.convert("RGB"))
    results = reader.readtext(arr, detail=1, paragraph=False)
    extracted: list[tuple[str, float]] = []
    for _, text, confidence in results:
        extracted.append((normalize_text(str(text)), float(confidence)))
    return extracted


def dedupe_rows(rows: Iterable[dict]) -> list[dict]:
    best: dict[str, dict] = {}
    for row in rows:
        key = title_key(row["作品名"])
        if not key:
            continue
        if key not in best or float(row["OCR信頼度"]) > float(best[key]["OCR信頼度"]):
            best[key] = row
    return sorted(best.values(), key=lambda r: (r["作品名"].lower(), r["画像名"]))


st.title(f"🎬 {APP_TITLE}")
st.caption("BUMPの作品一覧・検索結果などのスクリーンショットから、作品名候補を抽出して重複を除き、CSVに出力します。")

with st.expander("使い方", expanded=True):
    st.markdown(
        """
1. BUMPで作品一覧を上から順にスクロールし、重複部分を少し含めて連続スクリーンショットを撮ります。  
2. 下のアップローダーへ画像をまとめて投入します。  
3. OCR結果を確認し、作品名ではない行を削除・修正します。  
4. CSVをダウンロードします。表示漏れを避けるため、複数タブ・ジャンルがある場合はすべて撮影してください。
        """
    )

with st.sidebar:
    st.header("抽出設定")
    confidence_threshold = st.slider("OCR信頼度の下限", 0.0, 1.0, 0.35, 0.05)
    min_chars = st.number_input("作品名の最短文字数", min_value=1, max_value=20, value=2)
    max_chars = st.number_input("作品名の最長文字数", min_value=10, max_value=100, value=45)
    extra_excludes = st.text_area(
        "除外ワード（1行1語）",
        value="\n".join(sorted(DEFAULT_EXCLUDES)),
        height=260,
    )
    excludes = {normalize_text(x).lower() for x in extra_excludes.splitlines() if normalize_text(x)}

uploaded_files = st.file_uploader(
    "スクリーンショットをアップロード",
    type=["png", "jpg", "jpeg", "webp"],
    accept_multiple_files=True,
)

if "ocr_rows" not in st.session_state:
    st.session_state.ocr_rows = []

col1, col2 = st.columns([1, 1])
with col1:
    run_button = st.button("OCRを実行", type="primary", disabled=not uploaded_files, use_container_width=True)
with col2:
    clear_button = st.button("結果をクリア", use_container_width=True)

if clear_button:
    st.session_state.ocr_rows = []
    st.rerun()

if run_button and uploaded_files:
    all_rows: list[dict] = []
    progress = st.progress(0)
    status = st.empty()

    for idx, file in enumerate(uploaded_files, start=1):
        status.write(f"解析中: {file.name} ({idx}/{len(uploaded_files)})")
        image = Image.open(io.BytesIO(file.getvalue()))
        try:
            ocr_items = run_ocr(image)
        except Exception as exc:
            st.error(f"{file.name} のOCRに失敗しました: {exc}")
            continue

        for text, confidence in ocr_items:
            if confidence < confidence_threshold:
                continue
            if is_probable_title(text, excludes, int(min_chars), int(max_chars)):
                all_rows.append(
                    {
                        "採用": True,
                        "作品名": text,
                        "画像名": file.name,
                        "OCR信頼度": round(confidence, 3),
                        "メモ": "",
                    }
                )
        progress.progress(idx / len(uploaded_files))

    st.session_state.ocr_rows = dedupe_rows(all_rows)
    status.write(f"完了: {len(st.session_state.ocr_rows)}件の候補を抽出しました。")

if st.session_state.ocr_rows:
    st.subheader("抽出結果の確認")
    st.info("誤認識を修正し、作品名でない行は「採用」のチェックを外してください。")

    df = pd.DataFrame(st.session_state.ocr_rows)
    edited_df = st.data_editor(
        df,
        use_container_width=True,
        hide_index=True,
        num_rows="dynamic",
        column_config={
            "採用": st.column_config.CheckboxColumn("採用", default=True),
            "作品名": st.column_config.TextColumn("作品名", required=True, width="large"),
            "画像名": st.column_config.TextColumn("画像名", disabled=True),
            "OCR信頼度": st.column_config.NumberColumn("OCR信頼度", format="%.3f", disabled=True),
            "メモ": st.column_config.TextColumn("メモ"),
        },
        key="result_editor",
    )

    selected = edited_df[edited_df["採用"] == True].copy()  # noqa: E712
    selected["作品名"] = selected["作品名"].astype(str).map(normalize_text)
    selected["比較キー"] = selected["作品名"].map(title_key)
    selected = selected[selected["比較キー"] != ""]
    selected = selected.sort_values("OCR信頼度", ascending=False).drop_duplicates("比較キー", keep="first")
    selected = selected.drop(columns=["比較キー", "採用"])
    selected = selected.sort_values("作品名").reset_index(drop=True)
    selected.insert(0, "No.", range(1, len(selected) + 1))

    m1, m2, m3 = st.columns(3)
    m1.metric("ユニーク作品数", len(selected))
    m2.metric("候補総数", len(edited_df))
    m3.metric("除外数", len(edited_df) - len(selected))

    st.dataframe(selected, use_container_width=True, hide_index=True)

    csv_data = selected.to_csv(index=False).encode("utf-8-sig")
    st.download_button(
        "CSVをダウンロード",
        data=csv_data,
        file_name="bump_works.csv",
        mime="text/csv",
        type="primary",
        use_container_width=True,
    )
else:
    st.warning("まだ抽出結果がありません。スクリーンショットをアップロードしてOCRを実行してください。")

st.divider()
st.caption("注意: 本ツールは画面に表示された情報だけを集計します。非表示・限定公開・ジャンル別タブの撮り漏れがあると総作品数は少なく算出されます。")

# BUMP作品カウンター（スマホ版）

BUMPの作品一覧スクリーンショットを読み込み、OCRでタイトル候補を抽出し、重複除去・作品数集計・CSV保存を行うモバイル向けWebアプリです。

## スマホで使う方法

### 方法1：Webに公開して使う（推奨）
このフォルダ内の `index.html`、`manifest.webmanifest`、`sw.js` を、GitHub Pages、Netlify、Cloudflare Pagesなどの静的ホスティングへアップロードしてください。
公開URLをiPhoneまたはAndroidで開けば利用できます。

- iPhone：Safariの共有ボタン →「ホーム画面に追加」
- Android：Chromeメニュー →「ホーム画面に追加」または「アプリをインストール」

### 方法2：PCで簡易サーバーを起動して同一Wi-Fiのスマホから使う
PCでこのフォルダを開き、Pythonがある場合は次を実行します。

```bash
python -m http.server 8000
```

PCのローカルIPが `192.168.1.10` の場合、スマホで `http://192.168.1.10:8000` を開きます。

## 注意
- OCRはTesseract.jsをCDNから読み込むため、初回利用時にインターネット接続が必要です。
- OCR結果は必ず目視確認してください。
- BUMPのAPIや内部通信にはアクセスしません。
- 画像はブラウザ内で処理し、このツール自体はサーバーへアップロードしません。

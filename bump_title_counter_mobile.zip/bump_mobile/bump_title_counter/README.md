# BUMP 配信作品カウンター

BUMPアプリの作品一覧・検索結果画面のスクリーンショットをOCR解析し、作品名候補を重複除去してCSV出力するローカルWebアプリです。

## 特徴

- PNG / JPG / WEBPを複数同時アップロード
- 日本語・英語OCR
- メニュー語や話数などを自動除外
- 作品名候補の手動修正・削除
- 表記ゆれをある程度吸収した重複除去
- UTF-8 BOM付きCSV出力（Excelで文字化けしにくい）

## 起動方法

### Windows

1. Python 3.11をインストールします。
2. このフォルダでコマンドプロンプトを開きます。
3. 次を順番に実行します。

```bat
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

### macOS

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

ブラウザが自動で開かない場合は、ターミナルに表示される `http://localhost:8501` を開いてください。

## スクリーンショットの撮り方

1. BUMPの作品一覧を最上部から表示します。
2. 1画面ずつ下へスクロールして撮影します。
3. 前後の画像で1〜2作品が重なるようにすると、撮り漏れを抑えられます。
4. 「新着」「ランキング」「ジャンル別」など一覧が分かれている場合は、それぞれ撮影します。
5. ツール側で重複除去します。

## 精度を上げるコツ

- 端末の文字サイズを標準にする
- 画像を縮小せず、元サイズでアップロードする
- タイトルが画像や装飾文字のみの場合は、結果画面で手入力する
- メニュー名が混ざる場合は、左側の「除外ワード」に追加する

## 注意事項

- 画面に表示された作品だけを数えます。限定公開・配信終了・検索に出ない作品は取得できません。
- 初回起動時にEasyOCRの日本語・英語モデルをダウンロードします。
- BUMPの利用規約、著作権、社内の情報管理ルールに従って利用してください。
